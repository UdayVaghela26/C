#include<stdio.h>

int main()
{
    float a,b,x;
    printf("enter the value of a:");
    scanf("%f",&a);

    printf("enter the value of b:");
    scanf("%f",&b);

    x=a-b;
    printf("x = %f",x);
}