#include<stdio.h>

int main()
{
    float a,b,x;

    printf("entar value of a:");
    scanf("%f",&a);

        printf("entar value of b:");
    scanf("%f",&b);

    x=a/b;

    printf("x = %f",x);
}