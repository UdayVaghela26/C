#include<stdio.h>

int main()
{
    int a,b,x;

    printf("enter the value of a:");
    scanf("%d",&a);

    printf("enter the value of b:");
    scanf("%d",&b);


    printf("----------\n");
    printf("|\t |\n");
    printf("| %d*%d=%d |\n",a,b,a*b);
    printf("|\t |\n");
    printf("----------\n");



}